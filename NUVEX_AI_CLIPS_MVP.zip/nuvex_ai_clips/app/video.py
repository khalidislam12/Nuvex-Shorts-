import ipaddress, socket, re, json, subprocess, shutil, mimetypes
from urllib.parse import urlparse
from pathlib import Path
import httpx
from .config import VIDEO_DIR, MAX_UPLOAD_MB, MAX_URL_MB, GEMINI_API_KEY, GEMINI_MODEL

VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".mpeg", ".mpg"}

def validate_public_url(url: str):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("শুধু বৈধ HTTP/HTTPS ভিডিও URL ব্যবহার করুন।")
    host = parsed.hostname.lower()
    if host in ("localhost",) or host.endswith(".local"):
        raise ValueError("এই URL গ্রহণযোগ্য নয়।")
    try:
        for item in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(item[4][0])
            if not ip.is_global:
                raise ValueError("Private বা local network URL গ্রহণযোগ্য নয়।")
    except socket.gaierror:
        raise ValueError("ভিডিও URL-এর host খুঁজে পাওয়া যায়নি।")

async def download_direct_video(url: str, job_id: str) -> Path:
    validate_public_url(url)
    target = VIDEO_DIR / f"{job_id}_source.mp4"
    max_bytes = MAX_URL_MB * 1024 * 1024
    total = 0
    async with httpx.AsyncClient(follow_redirects=False, timeout=60) as client:
        async with client.stream("GET", url, headers={"User-Agent": "NuvexAIClips/1.0"}) as response:
            if response.status_code in (301, 302, 303, 307, 308):
                raise ValueError("Redirect URL সমর্থিত নয়। সরাসরি ভিডিও ফাইল URL দিন।")
            response.raise_for_status()
            ctype = response.headers.get("content-type", "").lower()
            if not (ctype.startswith("video/") or urlparse(url).path.lower().endswith(tuple(VIDEO_EXTS))):
                raise ValueError("URL-টি সরাসরি ভিডিও ফাইল হতে হবে (যেমন MP4)।")
            length = int(response.headers.get("content-length", "0") or 0)
            if length and length > max_bytes:
                raise ValueError(f"ভিডিও {MAX_URL_MB}MB সীমার চেয়ে বড়।")
            with target.open("wb") as out:
                async for chunk in response.aiter_bytes():
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError(f"ভিডিও {MAX_URL_MB}MB সীমার চেয়ে বড়।")
                    out.write(chunk)
    return target

def check_ffmpeg():
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise RuntimeError("FFmpeg/FFprobe ইনস্টল নেই।")

def video_duration(path: Path) -> float:
    check_ffmpeg()
    p = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True, timeout=30
    )
    if p.returncode != 0:
        raise ValueError("ভিডিও ফাইল পড়া যাচ্ছে না।")
    return float(p.stdout.strip())

def analyze_with_gemini(path: Path, requested_count: int, clip_seconds: int):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY সেট করা হয়নি।")
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=GEMINI_API_KEY)
    uploaded = client.files.upload(file=str(path))
    import time
    for _ in range(90):
        current = client.files.get(name=uploaded.name)
        state = getattr(current, "state", None)
        state_name = getattr(state, "name", str(state))
        if state_name == "ACTIVE":
            uploaded = current
            break
        if state_name == "FAILED":
            raise RuntimeError("Gemini ভিডিও ফাইল প্রসেস করতে পারেনি।")
        time.sleep(2)
    else:
        raise RuntimeError("Gemini ভিডিও প্রসেসিং টাইমআউট হয়েছে।")

    try:
        prompt = f"""
Analyze this video and select up to {requested_count} distinct, compelling short-video moments.
Each moment must be at most {clip_seconds} seconds. Use exact seconds from the source.
Return ONLY valid JSON: {{"clips":[{{"start":12.5,"end":52.0,"title":"...","description":"...","tags":["..."],"hashtags":["#..."]}}]}}
Rules:
- Timestamps must be within the video duration and end > start.
- Choose self-contained moments with a strong hook and useful context.
- Avoid overlapping moments when possible.
- Titles and descriptions should be concise and suitable for YouTube Shorts/Reels/TikTok.
- Do not invent events that are not in the video.
"""
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=[uploaded, prompt],
            config=types.GenerateContentConfig(response_mime_type="application/json")
        )
        raw = response.text or ""
        data = json.loads(raw)
        return data.get("clips", [])
    finally:
        try:
            client.files.delete(name=uploaded.name)
        except Exception:
            pass

def render_clip(source: Path, job_id: str, index: int, start: float, end: float, aspect: str):
    check_ffmpeg()
    duration = end - start
    if duration <= 0 or duration > 180:
        raise ValueError("AI একটি অবৈধ ক্লিপ টাইম রেঞ্জ দিয়েছে।")
    output = VIDEO_DIR / f"{job_id}_clip_{index}.mp4"
    vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920" if aspect == "9:16" else (
         "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080" if aspect == "1:1" else
         "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2")
    cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(duration),
           "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
           "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(output)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    if result.returncode != 0:
        raise RuntimeError("FFmpeg ভিডিও রেন্ডার করতে পারেনি: " + result.stderr[-500:])
    return output
