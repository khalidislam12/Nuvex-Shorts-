import sqlite3
from datetime import datetime, timezone
from .config import DB_PATH

def connect():
    db = sqlite3.connect(DB_PATH, check_same_thread=False)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          plan TEXT NOT NULL DEFAULT 'free',
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS jobs (
          id TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL,
          status TEXT NOT NULL,
          progress INTEGER NOT NULL DEFAULT 0,
          message TEXT NOT NULL DEFAULT '',
          result_json TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS usage (
          user_id INTEGER NOT NULL,
          day TEXT NOT NULL,
          used INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(user_id, day)
        );
        """)

def utc_now():
    return datetime.now(timezone.utc).isoformat()
