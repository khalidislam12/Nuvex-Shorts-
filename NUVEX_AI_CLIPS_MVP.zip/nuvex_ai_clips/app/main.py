import os, uuid, json, shutil, asyncio, re, time
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from .config import *
from .database import init_db, connect, utc_now
from .security import hash_password, verify_password, create_token, decode_token
from .video import download_direct_video, analyze_with_gemini, render_clip, video_duration, VIDEO_EXTS

app = FastAPI(title="NUVEX AI CLIPS", version="1.0.0")
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")
bearer = HTTPBearer(auto_error=False)

@app.on_event("startup")
def startup():
    init_db()
    cutoff = time.time() - JOB_RETENTION_HOURS * 3600
    for p in VIDEO_DIR.iterdir():
        try:
            if p.stat().st_mtime < cutoff:
                p.unlink(missing_ok=True)
        except Exception:
            pass

def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
    if not credentials:
        raise HTTPException(401, "Login প্রয়োজন।")
    payload = decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(401, "Session শেষ হয়েছে। আবার Login করুন।")
    with connect() as db:
        user = db.execute("SELECT id,email,plan FROM users WHERE id=?", (int(payload["sub"]),)).fetchone()
    if not user:
        raise HTTPException(401, "User পাওয়া যায়নি।")
    return dict(user)

class AuthInput(BaseModel):
    email: EmailStr
    password: str

class UrlJob(BaseModel):
    url: str
    duration: int = 45
    count: int = 3
    aspect: str = "9:16"

def daily_limit(user):
    return PREMIUM_DAILY_CREDITS if user["plan"] == "premium" else FREE_DAILY_CREDITS

def consume_credit(user):
    day = datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        row = db.execute("SELECT used FROM usage WHERE user_id=? AND day=?", (user["id"], day)).fetchone()
        used = row["used"] if row else 0
        limit = daily_limit(user)
        if used >= limit:
            raise HTTPException(429, f"আজকের ক্রেডিট শেষ ({limit}/{limit})।")
        db.execute("INSERT INTO usage(user_id,day,used) VALUES(?,?,1) ON CONFLICT(user_id,day) DO UPDATE SET used=used+1",
                   (user["id"], day))
        return used + 1, limit

def set_job(job_id, status=None, progress=None, message=None, results=None):
    fields, vals = [], []
    for key, value in [("status",status),("progress",progress),("message",message),
                       ("result_json",json.dumps(results,ensure_ascii=False) if results is not None else None)]:
        if value is not None:
            fields.append(f"{key}=?"); vals.append(value)
    if fields:
        vals.append(job_id)
        with connect() as db:
            db.execute(f"UPDATE jobs SET {','.join(fields)} WHERE id=?", vals)

async def process_job(job_id, user_id, source_path, duration, count, aspect):
    try:
        set_job(job_id, status="processing", progress=8, message="Gemini AI ভিডিও বিশ্লেষণ করছে...")
        source = Path(source_path)
        total_duration = video_duration(source)
        clips = await asyncio.to_thread(analyze_with_gemini, source, count, duration)
        if not clips:
            raise RuntimeError("Gemini কোনো উপযুক্ত Shorts moment খুঁজে পায়নি।")
        output = []
        for i, clip in enumerate(clips[:count], 1):
            start = max(0, float(clip.get("start", 0)))
            end = min(total_duration, float(clip.get("end", 0)))
            if end <= start:
                continue
            end = min(end, start + duration)
            set_job(job_id, progress=min(20 + int((i-1)/max(len(clips),1)*70), 90),
                    message=f"Short {i} রেন্ডার হচ্ছে...")
            rendered = await asyncio.to_thread(render_clip, source, job_id, i, start, end, aspect)
            output.append({
                "title": str(clip.get("title","AI Short"))[:120],
                "description": str(clip.get("description",""))[:500],
                "tags": clip.get("tags",[])[:15],
                "hashtags": clip.get("hashtags",[])[:15],
                "duration": round(end-start,1),
                "download_url": f"/api/jobs/{job_id}/download/{rendered.name}"
            })
        if not output:
            raise RuntimeError("কোনো ক্লিপ রেন্ডার হয়নি।")
        set_job(job_id, status="completed", progress=100, message="Shorts তৈরি সম্পন্ন!", results=output)
    except Exception as exc:
        set_job(job_id, status="failed", progress=100, message=str(exc)[:500])
    finally:
        try:
            Path(source_path).unlink(missing_ok=True)
        except Exception:
            pass

@app.get("/", response_class=HTMLResponse)
def home():
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "NUVEX AI CLIPS"}

@app.post("/api/auth/register")
def register(data: AuthInput):
    if len(data.password) < 8:
        raise HTTPException(400, "Password কমপক্ষে ৮ অক্ষরের হতে হবে।")
    with connect() as db:
        try:
            cur = db.execute("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)",
                             (data.email.lower(), hash_password(data.password), utc_now()))
            uid = cur.lastrowid
        except Exception:
            raise HTTPException(409, "এই Email দিয়ে অ্যাকাউন্ট আছে।")
    return {"token": create_token(uid, data.email.lower()), "user":{"id":uid,"email":data.email.lower(),"plan":"free"}}

@app.post("/api/auth/login")
def login(data: AuthInput):
    with connect() as db:
        user = db.execute("SELECT * FROM users WHERE email=?", (data.email.lower(),)).fetchone()
    if not user or not verify_password(data.password, user["password_hash"]):
        raise HTTPException(401, "Email অথবা Password ভুল।")
    return {"token":create_token(user["id"],user["email"]),
            "user":{"id":user["id"],"email":user["email"],"plan":user["plan"]}}

@app.get("/api/me")
def me(user=Depends(current_user)):
    day = datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        row = db.execute("SELECT used FROM usage WHERE user_id=? AND day=?", (user["id"],day)).fetchone()
    used = row["used"] if row else 0
    return {**user, "used_today":used, "daily_limit":daily_limit(user)}

@app.post("/api/jobs/url")
async def create_url_job(data: UrlJob, background: BackgroundTasks, user=Depends(current_user)):
    if data.duration not in (15,30,45,60,90):
        raise HTTPException(400,"Duration 15, 30, 45, 60 বা 90 সেকেন্ড হতে হবে।")
    if data.count not in (1,2,3,5):
        raise HTTPException(400,"Shorts count 1, 2, 3 বা 5 হতে হবে।")
    if data.aspect not in ("9:16","16:9","1:1"):
        raise HTTPException(400,"Invalid video format.")
    consume_credit(user)
    job_id = uuid.uuid4().hex[:12]
    try:
        source = await download_direct_video(data.url, job_id)
    except Exception as e:
        raise HTTPException(400,str(e))
    with connect() as db:
        db.execute("INSERT INTO jobs(id,user_id,status,progress,message,created_at) VALUES(?,?,?,?,?,?)",
                   (job_id,user["id"],"queued",0,"Job queue-তে যোগ হয়েছে",utc_now()))
    background.add_task(process_job,job_id,user["id"],str(source),data.duration,data.count,data.aspect)
    return {"success":True,"job_id":job_id,"message":"ভিডিও প্রসেসিং শুরু হয়েছে।"}

@app.post("/api/jobs/upload")
async def create_upload_job(background: BackgroundTasks, file: UploadFile = File(...),
                            duration: int = Form(45), count: int = Form(3), aspect: str = Form("9:16"),
                            user=Depends(current_user)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in VIDEO_EXTS:
        raise HTTPException(400,"MP4, MOV, MKV, WEBM বা AVI ভিডিও দিন।")
    if duration not in (15,30,45,60,90) or count not in (1,2,3,5) or aspect not in ("9:16","16:9","1:1"):
        raise HTTPException(400,"ভিডিও সেটিংস সঠিক নয়।")
    consume_credit(user)
    job_id = uuid.uuid4().hex[:12]
    target = VIDEO_DIR / f"{job_id}_source{suffix}"
    size = 0
    try:
        with target.open("wb") as out:
            while chunk := await file.read(1024*1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB*1024*1024:
                    raise HTTPException(413,f"সর্বোচ্চ Upload {MAX_UPLOAD_MB}MB।")
                out.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    with connect() as db:
        db.execute("INSERT INTO jobs(id,user_id,status,progress,message,created_at) VALUES(?,?,?,?,?,?)",
                   (job_id,user["id"],"queued",0,"Job queue-তে যোগ হয়েছে",utc_now()))
    background.add_task(process_job,job_id,user["id"],str(target),duration,count,aspect)
    return {"success":True,"job_id":job_id,"message":"ভিডিও প্রসেসিং শুরু হয়েছে।"}

@app.get("/api/jobs")
def list_jobs(user=Depends(current_user)):
    with connect() as db:
        rows = db.execute("SELECT id,status,progress,message,created_at,result_json FROM jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 30",
                          (user["id"],)).fetchall()
    return [{"id":r["id"],"status":r["status"],"progress":r["progress"],"message":r["message"],
             "created_at":r["created_at"],"clips":json.loads(r["result_json"])} for r in rows]

@app.get("/api/jobs/{job_id}")
def job_status(job_id: str, user=Depends(current_user)):
    with connect() as db:
        row = db.execute("SELECT * FROM jobs WHERE id=? AND user_id=?", (job_id,user["id"])).fetchone()
    if not row:
        raise HTTPException(404,"Job পাওয়া যায়নি।")
    return {"id":row["id"],"status":row["status"],"progress":row["progress"],
            "message":row["message"],"clips":json.loads(row["result_json"])}

@app.get("/api/jobs/{job_id}/download/{filename}")
def download(job_id: str, filename: str, user=Depends(current_user)):
    if not re.fullmatch(r"[a-f0-9]{12}_clip_[0-9]+\.mp4", filename):
        raise HTTPException(400,"Invalid filename.")
    with connect() as db:
        row = db.execute("SELECT id FROM jobs WHERE id=? AND user_id=?", (job_id,user["id"])).fetchone()
    if not row or not filename.startswith(job_id):
        raise HTTPException(404,"File পাওয়া যায়নি।")
    path = VIDEO_DIR / filename
    if not path.exists():
        raise HTTPException(410,"ভিডিওর অস্থায়ী ডাউনলোড লিংকের মেয়াদ শেষ। আবার তৈরি করুন।")
    if path.stat().st_mtime < time.time() - JOB_RETENTION_HOURS * 3600:
        path.unlink(missing_ok=True)
        raise HTTPException(410,"ভিডিওর অস্থায়ী ডাউনলোড লিংকের মেয়াদ শেষ। আবার তৈরি করুন।")
    return FileResponse(path, media_type="video/mp4", filename=filename)

@app.get("/api/admin/stats")
def admin_stats(user=Depends(current_user)):
    # MVP: Admin is enabled only for an email explicitly set in ADMIN_EMAIL.
    if user["email"] != os.getenv("ADMIN_EMAIL",""):
        raise HTTPException(403,"Admin access নেই।")
    with connect() as db:
        users = db.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        jobs = db.execute("SELECT COUNT(*) n FROM jobs").fetchone()["n"]
        completed = db.execute("SELECT COUNT(*) n FROM jobs WHERE status='completed'").fetchone()["n"]
    return {"users":users,"jobs":jobs,"completed_jobs":completed}
