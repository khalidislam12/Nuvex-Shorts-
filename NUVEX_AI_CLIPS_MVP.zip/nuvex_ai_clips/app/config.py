import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("DATA_DIR", "/tmp/nuvex_ai_clips"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
VIDEO_DIR = DATA_DIR / "videos"
VIDEO_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.getenv("DB_PATH", str(DATA_DIR / "nuvex.db")))

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
JWT_SECRET = os.getenv("JWT_SECRET", "CHANGE_THIS_BEFORE_DEPLOYMENT")
TOKEN_HOURS = int(os.getenv("TOKEN_HOURS", "72"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
MAX_URL_MB = int(os.getenv("MAX_URL_MB", "500"))
FREE_DAILY_CREDITS = int(os.getenv("FREE_DAILY_CREDITS", "3"))
PREMIUM_DAILY_CREDITS = int(os.getenv("PREMIUM_DAILY_CREDITS", "30"))
JOB_RETENTION_HOURS = int(os.getenv("JOB_RETENTION_HOURS", "6"))
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*")
