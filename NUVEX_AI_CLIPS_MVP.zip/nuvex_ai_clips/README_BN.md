# NUVEX AI CLIPS — MVP

Gemini AI + FastAPI + FFmpeg দিয়ে long video থেকে short clips তৈরি করার starter project.

## কী আছে
- Premium dark responsive dashboard
- Email/password register/login (JWT)
- SQLite user/job/usage data (MVP)
- Free daily 3 credits; Premium daily 30 credits (Premium manual/admin setup only)
- Video upload অথবা direct public MP4 URL
- Gemini video understanding দিয়ে timestamp, title, description, tags, hashtags
- FFmpeg clip rendering এবং download
- Temporary files `/tmp/nuvex_ai_clips`-এ রাখা হয়; cleanup startup-এ retention window অনুযায়ী হয়
- Admin stats endpoint: `ADMIN_EMAIL` environment variable-এ admin email সেট করলে

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. YouTube watch URL / Facebook / TikTok page URL সরাসরি MP4 URL নয়। MVP সেগুলো scrape/download করে না। Direct MP4 URL বা নিজের ভিডিও upload করুন। Platform API ও content rights অনুযায়ী integration পরে যোগ করতে হবে।
2. প্রথম MVP-তে captions নির্বাচন UI/metadata আছে, কিন্তু burned-in word-level subtitle generation এখনো নেই। এটি পরের development milestone.
3. Premium payment checkout/automatic upgrade এখনো নেই। Payment verification না করে plan unlock করা হয়নি।
4. SQLite এবং in-memory BackgroundTasks এক-instance MVP-এর জন্য। Production-এ Postgres + Redis/Celery/Render Worker বা managed queue ব্যবহার করুন।
5. Temporary storage মানে Render restart/deploy হলে ফাইল হারাতে পারে। এই সেটআপে downloads অস্থায়ী।
6. Gemini API usage billed/quota-limited হতে পারে। API key গোপন রাখুন, frontend-এ দেবেন না।
7. User-এর নিজের বা ব্যবহারের অনুমতি থাকা ভিডিওই প্রসেস করুন।

## Termux setup

প্রথমে Termux-এ:

```bash
pkg update -y && pkg upgrade -y
pkg install python git ffmpeg nano -y
python -m pip install --upgrade pip
```

ZIP extract করার পরে project folder-এ:

```bash
cd nuvex_ai_clips
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

`.env`-এ নিজের Gemini API key বসান। JWT_SECRET অবশ্যই বদলান। `.env` GitHub-এ push করবেন না।

Run:

```bash
export $(grep -v '^#' .env | xargs)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Android browser-এ খুলুন:

`http://127.0.0.1:8000`

Termux-এ FFmpeg ঠিক আছে কি না:

```bash
ffmpeg -version
ffprobe -version
```

## Render deployment

1. GitHub-এ নতুন private repository বানান।
2. Project folder-এর ফাইল GitHub-এ push করুন।
3. Render Dashboard → New → Blueprint অথবা Web Service।
4. Repository connect করুন। `render.yaml` Blueprint ব্যবহার করলে service settings তৈরি হবে।
5. Render Environment-এ `GEMINI_API_KEY` দিন।
6. `JWT_SECRET` Render-generated value রাখুন।
7. Deploy করুন। `/api/health` খুলে `{"ok":true,...}` দেখুন।

Dockerfile FFmpeg ইনস্টল করে। Render-এর Docker service port `$PORT` ব্যবহার করে।

## GitHub push (Termux)

```bash
git init
git add .
git commit -m "Initial Nuvex AI Clips MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nuvex-ai-clips.git
git push -u origin main
```

GitHub-এ `.env` যেন না যায়; `.gitignore`-এ `.env` আছে।

## Render free tier বিষয়ে
ভিডিও processing CPU/RAM-heavy এবং free instance spin down হতে পারে। এই MVP free tier-এ নির্ভরযোগ্য production video service হিসেবে ধরা যাবে না। Docker build এবং FFmpeg processing-এর জন্য পর্যাপ্ত compute লাগবে। Render-এর current plan, usage, sleep এবং disk rules deploy-এর আগে যাচাই করুন।

## Troubleshooting
- `GEMINI_API_KEY সেট করা হয়নি`: local `.env` export করুন অথবা Render Environment-এ key দিন।
- `FFmpeg/FFprobe ইনস্টল নেই`: Termux-এ `pkg install ffmpeg`; Render Dockerfile deploy করুন।
- `Unexpected end of JSON input`: browser Network tab/server logs দেখুন; এই frontend response text parse করে invalid JSON হলে readable error দেখায়।
- Download 410: temporary file expiry বা restart হয়েছে; নতুন job তৈরি করুন।
- URL rejected: direct publicly reachable MP4 URL দিন; redirect, private network ও webpage URL blocked।
